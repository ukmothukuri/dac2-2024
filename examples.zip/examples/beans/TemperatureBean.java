package beans;
public class TemperatureBean{
	private String temp;
	public String getTemperature()
	{
		return temp;
	}
	public void setTemperature(String t)
	{
		temp = t;
	}
}
