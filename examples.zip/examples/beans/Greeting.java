package beans;
public class Greeting
{
	private String greeting; // the property
	public Greeting()
	{
		greeting = "Hello World";
	}
	
	public String getGreeting()
	{
		return greeting;
	}
	public void setGreeting(String g)
	{
		greeting = (g == null) ? "Hello World" : g;
	}
}
