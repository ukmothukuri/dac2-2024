package beans;
import java.text.DecimalFormat;
public class TemperatureCalculatorBean
	{   private double celsius;   public String getTemperature()   {      return        new DecimalFormat("0.00").format(celsius);   }   
	public void setTemperature(String fahr)   {      double f;      try      {         f = Double.parseDouble(fahr);      }      catch (NumberFormatException e)      {         f = 0.0;      }      celsius = (f - 32.0) * (5.0 / 9.0);   }}   
