package beans;
public class NameBean
{
	private String firstName; // property
	private String lastName;  // property
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public void setFirstName(String first)
	{
		firstName = first;
	}
	public void setLastName(String last)
	{
		lastName = last;
	}
	}
